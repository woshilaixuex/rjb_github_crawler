# Changelog
All notable changes to this project will be documented in this file.
## v3.0.11
Added
- 事件服务器添加跳过验签的选项
## v3.0.10
Added
- 更新业务功能
## v3.0.9
Added
- 更新业务功能
## v3.0.8
Added
- 更新业务功能

## v3.0.5
Added
- 更新业务功能，比如docx评论相关api

## v3.0.4
Added
- 添加调用示例

## v3.0.3
Added
- 初始化client时，提供withHeaders选项，让开发者设置一些在所有请求都是用的header，比如环境标

## v3.0.2
Fixed
- 修改枚举值名称为：methodName+resourceName+enumValue

## v3.0.1
Added
- API方法，消息事件，各种结构体添加文字描述注释

## v3.0.0-beta-7-2022-08-12
Added
- 消息卡片添加MessageCardEmbedImage结构体

## v3.0.0-beta-6-2022-08-05
Added
- 添加 API 调用时，让开发者传递 appTicket,SDK内部根据appticket自动获取token的功能
- 添加获取登录用户身份、刷新 access_token，获取用户信息（身份验证）的接口
## v3.0.0-beta-5-2022-08-01
Added
- 添加 多维表格结果解析器

## v3.0.0-beta-4-2022-07-27
Added
- 添加所有 API 的使用 Demo

## v3.0.0-beta-3-2022-07-10
Fixed
- 对path参数进行encode

## v3.0.0-beta-2-2022-06-30
Added
- 添加所有 V1.0 协议的消息处理器

## v3.0.0-beta-1-2022-06-15
Added
- 添加 v3 的代码